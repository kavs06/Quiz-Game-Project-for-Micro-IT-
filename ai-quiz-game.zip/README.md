# 🧠 AI/ML Quiz Game 🎮

A simple AI-powered quiz game that adjusts question difficulty based on the user's performance. Great for beginners to understand basic ML integration in Python projects.

## 🔍 Features
- Multiple-choice questions about AI/ML.
- Dynamic difficulty adjustment using a Decision Tree.
- Simple terminal interface.
- Easy to expand with more features or UI.

## 🛠️ Tech Stack
- Python
- Scikit-learn
- JSON (for question storage)

## 🚀 How It Works
1. User answers 3 questions.
2. After each question, the AI model predicts the next difficulty level based on the score.
3. Game ends with final score display.

## 📦 Installation
```bash
git clone https://github.com/yourusername/ai-quiz-game.git
cd ai-quiz-game
pip install -r requirements.txt
python game.py
```

## 📝 Question Format
Stored in `data/questions.json`:
```json
{
  "question": "What is supervised learning?",
  "options": ["Unlabeled data", "Labeled data", "No data", "Random data"],
  "answer": "Labeled data",
  "difficulty": "easy"
}
```

## 📈 ML Component
The `DifficultyPredictor` uses a basic decision tree to classify the next difficulty based on current score.

## 💡 Future Enhancements
- Web UI using Streamlit or Flask
- Voice input/output
- Category-based quizzes
- Leaderboard and user tracking

## 📜 License
MIT License
