import json
from model.difficulty_predictor import DifficultyPredictor

def load_questions(difficulty):
    with open('data/questions.json', 'r') as file:
        all_questions = json.load(file)
    return [q for q in all_questions if q['difficulty'] == difficulty]

def run_quiz():
    predictor = DifficultyPredictor()
    score = 0

    for round_num in range(3):
        difficulty = predictor.predict(score)
        questions = load_questions(difficulty)
        if not questions:
            print("No questions available.")
            break

        question = questions[0]
        print(f"\nQ{round_num + 1}: {question['question']}")
        for idx, option in enumerate(question['options']):
            print(f"  {idx + 1}. {option}")

        try:
            answer = int(input("Your answer (1-4): "))
        except:
            print("Invalid input. Skipping question.")
            continue

        if question['options'][answer - 1] == question['answer']:
            print("✅ Correct!")
            score += 1
        else:
            print(f"❌ Wrong! Correct answer: {question['answer']}")

    print(f"\nYour final score: {score}/3")

if __name__ == "__main__":
    run_quiz()
