from sklearn.tree import DecisionTreeClassifier

class DifficultyPredictor:
    def __init__(self):
        self.model = DecisionTreeClassifier()
        self._train_model()

    def _train_model(self):
        # Example: score out of 5 → difficulty level
        X = [[0], [1], [2], [3], [4], [5]]
        y = ["easy", "easy", "medium", "medium", "hard", "hard"]
        self.model.fit(X, y)

    def predict(self, score):
        return self.model.predict([[score]])[0]
